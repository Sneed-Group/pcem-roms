See XTIDE Universal BIOS page for latest version and wiki manual:
http://code.google.com/p/xtideuniversalbios/

XTIDE Universal BIOS and included utilities are Copyright 2011-2012 by
XTIDE Universal BIOS Team. XTIDE Universal BIOS v1.1.5 and older are Copyright
2009-2010 by Tomi Tilli.

Released under GNU GPL v2. This software comes with
ABSOLUTELY NO WARRANTY. This is free software, and you are welcome to
redistribute it under certain conditions. See the LICENSE.TXT file that was
included with this distribution, visit http://www.gnu.org/licenses/gpl-2.0.html,
or visit http://code.coogle.com/p/xtideuniversalbios.