# Contributing

If you found some new roms please [e-mail me](mailto:barrakudarain@gmail.com) or create a pull request.
Please describe extended what type of hardware was added. 
Currently I'm looking for Elonex PC-425X I'll be pleasant if you contribute it to my repository.
Everyone who contributed will be mentioned in this file.

# Contributors

* Me
* Alexander Bulachevsky
* Tobias Mädel
